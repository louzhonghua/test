<template>
  <h2>分类</h2>
</template>

<script>
  export default {
    name: "Category"
  }
</script>

<style scoped>

</style>
